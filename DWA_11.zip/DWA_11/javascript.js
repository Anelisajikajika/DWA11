// Initial state
let state = {
  count: 0
};

// Action types
const ADD = 'ADD';
const SUBTRACT = 'SUBTRACT';
const RESET = 'RESET';

// Reducer function
function counterReducer(state, action) {
  switch (action.type) {
    case ADD:
      return { count: state.count + 1 };
    case SUBTRACT:
      return { count: state.count - 1 };
    case RESET:
      return { count: 0 };
    default:
      return state;
  }
}

// Function to dispatch actions
function dispatch(action) {
  state = counterReducer(state, action);
  render();
}

// Function to render the state
function render() {
  document.getElementById('count').innerText = `Count: ${state.count}`;
}

// Event listeners
document.getElementById('addButton').addEventListener('click', () => dispatch({ type: ADD }));
document.getElementById('subtractButton').addEventListener('click', () => dispatch({ type: SUBTRACT }));
document.getElementById('resetButton').addEventListener('click', () => dispatch({ type: RESET }));

// Fixed event listener for logging state
document.getElementById('logStateButton').addEventListener('click', () => console.log(state));

// Initial render
render();